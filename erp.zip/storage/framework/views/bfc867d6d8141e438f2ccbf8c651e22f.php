<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">
        <a href="<?php echo e(route('Report')); ?>" class="btn btn-info my-3 mx-3">Report</a>
        <div class="row">
            <div class="col-lg-12">
                <div class="card" id="printContent">
                    <div class="card-header">
                        <div class="d-flex">
                            <img src="<?php echo e(asset('ixony.png')); ?>" alt="">
                            <h3>Engineering Limited</h3>
                        </div>

                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <tr>
                                <th>SL</th>
                                <th>Type</th>
                                <th>Date</th>
                                <th>Total Product</th>
                            </tr>

                            <?php if($reports != ''): ?>
                                <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl => $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($report->type == 'Purchase'): ?>
                                        <?php
                                            $product = App\Models\PurchaseProduct::where('bundle_id', $report->bundle_id)->count();
                                        ?>
                                    <?php elseif($report->type == 'Challan'): ?>
                                        <?php
                                            $product = App\Models\ChallanProduct::where('bundle_id', $report->bundle_id)->count();
                                        ?>
                                    <?php else: ?>
                                        <?php
                                            $product = App\Models\ChallanReturnProduct::where('bundle_id', $report->bundle_id)->count();
                                        ?>
                                    <?php endif; ?>


                                    <tr class="report" data-url="<?php echo e(route('Report.Product', $report->bundle_id)); ?>">
                                        <td><?php echo e($sl + 1); ?></td>
                                        <td><?php echo e($report->type); ?></td>
                                        <td><?php echo e($report->date); ?></td>
                                        <td><?php echo e($product); ?></td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    No Records Found
                                <?php endif; ?>
                            <?php endif; ?>


                        </table>

                    </div>
                </div>


            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        const report = document.querySelectorAll('.report');
        report.forEach((item) => {
            item.addEventListener('click', function() {
                let dataURL = item.getAttribute('data-url');
                location.href = dataURL;
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\erp-solution\resources\views/admin/challan/showReport.blade.php ENDPATH**/ ?>