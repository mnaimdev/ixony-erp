<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add_purchase')): ?>
            <button type="button" class="btn btn-primary my-3" data-toggle="modal" data-target="#exampleModal">
                Add New
            </button>
        <?php endif; ?>


        <div class="row">

            <div class="col-lg-12 col-sm-12 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="mt-2">Purchase List</h3>
                    </div>
                    <div class="card-body">

                        <table class="table table-striped">
                            <tr>
                                <th>SL</th>
                                <th>Date</th>
                                <th>Purchase From</th>
                                <th>Supplier Challan No</th>
                                <th>Details</th>
                                <th>Action</th>
                            </tr>
                            <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl => $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($sl + 1); ?></td>
                                    <td><?php echo e($purchase->date); ?></td>
                                    <td><?php echo e($purchase->purchase_from); ?></td>
                                    <td><?php echo e($purchase->supplier_challan_no); ?></td>
                                    <td><?php echo e($purchase->details); ?></td>
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_purchase')): ?>
                                            <a href="<?php echo e(route('Product.Purchase.Edit', $purchase->id)); ?>"
                                                class="btn btn-primary">Edit</a>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchase_product')): ?>
                                            <a href="<?php echo e(route('Purchase.Product.Add', $purchase->bundle_id)); ?>"
                                                class="btn btn-info">Product</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>
                    </div>
                </div>
            </div>



            <!-- Modal -->
            
            <div class="modal fade" id="exampleModal" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title m-auto" id="exampleModalLabel">Create New Purchase</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('Product.Purchase.Store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>




                                <div class="col-lg-12">
                                    <div class="my-2">
                                        <label>Date</label>
                                        <input type="date" id="date" name="date" placeholder="Date"
                                            class="form-control" value="<?php echo e(old('date')); ?>">
                                        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <strong class="text-danger">
                                                <?php echo e($message); ?>

                                            </strong>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>


                                <div class="col-lg-12">
                                    <div class="my-2">
                                        <label>Purchase From</label>
                                        <input type="text" id="purchase_from" name="purchase_from"
                                            placeholder="Purchase From" class="form-control"
                                            value="<?php echo e(old('purchase_from')); ?>">
                                    </div>
                                </div>


                                <div class="col-lg-12">
                                    <div class="my-2">
                                        <label>Supplier Challan No</label>
                                        <input type="text" id="supplier_challan_no" name="supplier_challan_no"
                                            placeholder="Supplier Challan No" class="form-control"
                                            value="<?php echo e(old('supplier_challan_no')); ?>">
                                    </div>
                                </div>



                                <div class="col-lg-12">
                                    <div class="my-2">
                                        <label>Details</label>
                                        <textarea name="details" id="details" cols="20" rows="4" class="form-control"><?php echo e(old('details')); ?></textarea>
                                    </div>
                                </div>


                        </div>


                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\erp-solution\resources\views/admin/purchase/purchase.blade.php ENDPATH**/ ?>