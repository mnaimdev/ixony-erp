<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">


        <div class="col-lg-12 m-auto col-sm-12 col-md-12">
            <a href="<?php echo e(route('Product.Challan.Return')); ?>" class="btn btn-primary my-3">List</a>

            <div class="card">
                <div class="card-header">
                    <h3 class="text-center">View Returned Challan</h3>
                </div>



                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <ul class="list-group">
                                <li class="list-group-item"><b>Product: </b><?php echo e($returnedChallan->product->title); ?></li>
                                <li class="list-group-item"><b>Quantity: </b><?php echo e($returnedChallan->quantity); ?></li>
                                <li class="list-group-item"><b>Date: </b><?php echo e($returnedChallan->date); ?></li>

                                <li class="list-group-item"><b>Created By: </b><?php echo e($returnedChallan->user->name); ?></li>
                                <li class="list-group-item"><b>Customer Name: </b><?php echo e($returnedChallan->customer_name); ?></li>

                            </ul>
                        </div>


                        <div class="col-lg-6">
                            <ul class="list-group">
                                <li class="list-group-item"><b>Challan No: </b><?php echo e($returnedChallan->challan_no); ?></li>
                                <li class="list-group-item"><b>Delivery Location:
                                    </b><?php echo e($returnedChallan->delivery_location); ?></li>
                                <li class="list-group-item"><b>Contact Person: </b><?php echo e($returnedChallan->contact_person); ?>

                                </li>
                                <li class="list-group-item"><b>Contact Number: </b><?php echo e($returnedChallan->contact_number); ?>

                                </li>
                                <li class="list-group-item"><b>Challan Id: </b><?php echo e($returnedChallan->tran_id); ?></li>


                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\erp-solution\resources\views/admin/return/viewChallanReturn.blade.php ENDPATH**/ ?>