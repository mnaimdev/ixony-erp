<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">
        <div class="row">
            <div class="col-lg-8 m-auto">
                <div class="card">
                    <div class="card-header">
                        <h3>Report Generate</h3>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('Report.Generate')); ?>" method="POST" class="my-3">

                            <?php echo csrf_field(); ?>

                            <div class="my-2">
                                <label>Start Date</label>
                                <input type="date" name="start_date" class="form-control">
                            </div>

                            <div class="my-2">
                                <label>End Date</label>
                                <input type="date" name="end_date" class="form-control">
                            </div>

                            <div class="my-2">
                                <label>Type</label>
                                <select name="type" class="form-control">
                                    <option>Type</option>
                                    <option value="Purchase">Purchase</option>
                                    <option value="Challan">Challan</option>
                                    <option value="Return">Return</option>
                                </select>
                            </div>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('report_submit')): ?>
                                <div class="my-2">
                                    <button type="submit" class="btn btn-primary mx-2">Submit</button>
                                </div>
                            <?php endif; ?>

                        </form>
                    </div>
                </div>


            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\Office Project\erp-solution\resources\views/admin/challan/report.blade.php ENDPATH**/ ?>