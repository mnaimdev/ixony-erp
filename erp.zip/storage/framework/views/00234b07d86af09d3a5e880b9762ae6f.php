<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">
        <a href="<?php echo e(route('Employee.Create')); ?>" class="btn btn-primary my-2">Add New</a>
        <div class="card">
            <div class="card-header">
                <h3 class="text-center">Employee List</h3>
            </div>

            <div class="card-body">
                <table class="table">
                    <thead>
                        <th>SL</th>
                        <th>Name</th>
                        <th>Designation</th>
                        <th>Photo</th>
                        <th>NID Photo</th>
                        <th>Status</th>
                        <th>Action</th>
                    </thead>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tbody>

                            <tr>
                                <td>
                                    <?php echo e($sl + 1); ?>

                                </td>
                                <td>
                                    <h5 class="font-14 my-1 fw-normal"><?php echo e($employee->name); ?></h5>
                                </td>

                                <td>
                                    <h5 class="font-14 my-1 fw-normal"><?php echo e($employee->designation); ?></h5>
                                </td>


                                <td>
                                    <img width="50" height="50"
                                        src="<?php echo e(asset('/uploads/employee')); ?>/<?php echo e($employee->photo); ?>" alt="">
                                </td>
                                <td>
                                    <img width="50" height="50"
                                        src="<?php echo e(asset('/uploads/employee/nid')); ?>/<?php echo e($employee->nid_photo); ?>"
                                        alt="">
                                </td>
                                <td>
                                    <div class="form-check form-switch">
                                        <input data-id="<?php echo e($employee->id); ?>" class="form-check-input toggle-class"
                                            type="checkbox" id="flexSwitchCheckChecked" data-onstyle="success"
                                            data-offstyle="danger" data-toggle="toggle" data-on="Active" data-off="InActive"
                                            <?php echo e($employee->status ? 'checked' : ''); ?>>
                                    </div>
                                </td>


                                <td>
                                    <a href="<?php echo e(route('Employee.Edit', $employee->id)); ?>" class="btn btn-primary">Edit</a>
                                    <a href="<?php echo e(route('Employee.View', $employee->id)); ?>" class="btn btn-info">View</a>
                                </td>

                            </tr>

                        </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(function() {
            $('.toggle-class').change(function() {

                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Resigned Employee'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // code goes here
                        var status = $(this).prop('checked') == true ? 1 : 0;
                        var id = $(this).data('id');


                        $.ajax({
                            type: "GET",
                            dataType: "json",
                            url: '/changeStatus',
                            data: {
                                'status': status,
                                'id': id
                            },
                            success: function(data) {
                                alert(data.success);
                            }

                        })
                    }
                })

            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\erp-solution\resources\views/admin/employee/employee.blade.php ENDPATH**/ ?>