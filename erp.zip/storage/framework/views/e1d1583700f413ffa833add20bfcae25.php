<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">


        <div class="col-lg-8 m-auto col-sm-12 col-md-12">
            <a href="<?php echo e(route('product')); ?>" class="btn btn-primary my-3">List</a>

            <div class="card">
                <div class="card-header">
                    <h3>Edit Product</h3>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('product.update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>


                        <input type="hidden" name="id" value="<?php echo e($product->id); ?>">

                        <div class="row">
                            <div class="col-lg-6">
                                <div class="my-2">
                                    <label>Title</label>
                                    <input type="text" id="title" name="title" placeholder="Title"
                                        class="form-control" value="<?php echo e($product->title); ?>">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="my-2">
                                    <label>Series</label>
                                    <input type="text" id="series" name="series" placeholder="Series"
                                        class="form-control" value="<?php echo e($product->series); ?>">

                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-lg-6">
                                <div class="my-2">
                                    <label>Details</label>
                                    <textarea name="details" id="details" cols="20" rows="4" class="form-control" placeholder="Details">
                                        <?php echo e($product->details); ?>

                                    </textarea>

                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="my-2">
                                    <label>Model</label>
                                    <input type="text" id="model" name="model" placeholder="Model"
                                        class="form-control" value="<?php echo e($product->model); ?>">

                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-lg-6">
                                <div class="my-2">
                                    <label>Category</label>
                                    <select name="category" class="form-control">
                                        <option selected disabled>Select Category</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->name); ?>"
                                                <?php echo e($product->category == $category->name ? 'selected' : ''); ?>>
                                                <?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="my-2">
                                    <label>Brand</label>
                                    <input type="text" id="brand" name="brand" placeholder="Brand"
                                        class="form-control" value="<?php echo e($product->brand); ?>">

                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-lg-6">
                                <div class="my-2">
                                    <label>Origin</label>
                                    <input type="text" id="origin" name="origin" placeholder="Origin"
                                        class="form-control" value="<?php echo e($product->origin); ?>">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="my-2">
                                    <label>Country of Manufacturing</label>
                                    <input type="text" id="country_of_manufacturing" name="country_of_manufacturing"
                                        placeholder="Country of manufacturing" class="form-control"
                                        value="<?php echo e($product->country_of_manufacturing); ?>">
                                </div>
                            </div>
                        </div>



                        <div class="row">
                            <div class="col-lg-6">
                                <div class="my-2">
                                    <label>Base Unit</label>
                                    <input type="number" id="base_unit" name="base_unit" placeholder="Base Unit"
                                        class="form-control" value="<?php echo e($product->base_unit); ?>">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="my-2">
                                    <label>Current Price</label>
                                    <input type="number" id="current_price" name="current_price"
                                        placeholder="Current Price" class="form-control"
                                        value="<?php echo e($product->current_price); ?>">
                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-lg-6">
                                <div class="my-2">
                                    <label>Current Stock</label>
                                    <input type="number" id="current_stock" name="current_stock"
                                        placeholder="Current Stock" class="form-control"
                                        value="<?php echo e($product->current_stock); ?>">
                                </div>
                            </div>



                            <div class="col-lg-6">
                                <div class="my-2">
                                    <label>Stock Limit</label>
                                    <input type="number" id="stock_limit" name="stock_limit" placeholder="Stock Limit"
                                        class="form-control" value="<?php echo e($product->stock_limit); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <button class="btn btn-primary" type="submit">Update</button>
                        </div>



                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\default-structure\resources\views/admin/product/editProduct.blade.php ENDPATH**/ ?>