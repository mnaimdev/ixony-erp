<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">
        <form action="<?php echo e(route('Challan.Report.Count')); ?>" method="GET" class="my-3">
            Start Date: <input type="date" name="start_date">
            End Date: <input type="date" name="end_date">
            <button type="submit" class="btn btn-primary mx-2">Submit</button>
        </form>
        <div class="row">

            <div class="col-lg-12 col-sm-12 col-md-12">
                <div class="card">
                    <div class="card-header">

                        <h3 class="mt-2">Challan List</h3>
                    </div>
                    <div class="card-body">

                        <table class="table table-striped">
                            <tr>
                                <th>SL</th>
                                <th>Date</th>
                                <th>Challan No</th>
                                <th>Work Order No</th>
                                <th>Return Type</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            

                        </table>
                    </div>
                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\erp-solution\resources\views/admin/challan/challanReport.blade.php ENDPATH**/ ?>