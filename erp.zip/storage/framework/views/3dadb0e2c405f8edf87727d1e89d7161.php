<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">
        <a href="<?php echo e(route('Employee')); ?>" class="btn btn-primary my-2">List</a>
        <div class="card">
            <div class="card-header">
                <h3 class="text-center">Add Employee</h3>
            </div>

            <div class="card-body">
                <form class="col" method="POST" action="<?php echo e(route('Employee.Store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>


                    <?php if(session('employee')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('employee')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-lg-6">
                            <label class="my-1">Name</label>
                            <input type="text" class="form-control" placeholder="Name" name="name"
                                value="<?php echo e(old('name')); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger">
                                    <?php echo e($message); ?>

                                </strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                        <div class="col-lg-6">
                            <label class="my-1">Designation</label>
                            <input type="text" class="form-control" placeholder="Designation" name="designation"
                                value="<?php echo e(old('designation')); ?>">
                            <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger">
                                    <?php echo e($message); ?>

                                </strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                    <div class="row my-3">
                        <div class="col-lg-6">
                            <label class="my-1">Current Address</label>
                            <input type="text" class="form-control" placeholder="Current Address" name="current_address"
                                value="<?php echo e(old('current_address')); ?>">
                            <?php $__errorArgs = ['current_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger">
                                    <?php echo e($message); ?>

                                </strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-lg-6">
                            <label class="my-1">Permanent Address</label>
                            <input type="text" class="form-control" placeholder="Permanent Address"
                                name="permanent_address" value="<?php echo e(old('permanent_address')); ?>">
                            <?php $__errorArgs = ['permanent_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger">
                                    <?php echo e($message); ?>

                                </strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                    <div class="row my-3">
                        <div class="col-lg-6">
                            <label class="my-1">Personal Contact Number</label>
                            <input type="number" class="form-control" placeholder="Personal Contract Number"
                                name="personal_contract_number" value="<?php echo e(old('personal_contract_number')); ?>">
                            <?php $__errorArgs = ['personal_contract_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger">
                                    <?php echo e($message); ?>

                                </strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-lg-6">
                            <label class="my-1">Office Contact Number</label>
                            <input type="number" class="form-control" placeholder="Office Contract Number"
                                name="office_contract_number" value="<?php echo e(old('office_contract_number')); ?>">

                            <?php $__errorArgs = ['office_contract_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger">
                                    <?php echo e($message); ?>

                                </strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                    <div class="row my-3">
                        <div class="col-lg-6">
                            <label class="my-1">Whatsapp Number</label>
                            <input type="number" class="form-control" placeholder="Whatsapp Number" name="whatsapp_number"
                                value="<?php echo e(old('whatsapp_number')); ?>">
                            <?php $__errorArgs = ['whatsapp_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger">
                                    <?php echo e($message); ?>

                                </strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-lg-6">
                            <label class="my-1">Email</label>
                            <input type="text" class="form-control" placeholder="Email" name="email"
                                value="<?php echo e(old('email')); ?>">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger">
                                    <?php echo e($message); ?>

                                </strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>



                    <div class="row my-3">
                        <div class="col-lg-6">
                            <label class="my-1">NID Number</label>
                            <input type="text" class="form-control" placeholder="NID Number" name="nid_number"
                                value="<?php echo e(old('nid_number')); ?>">
                            <?php $__errorArgs = ['nid_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger">
                                    <?php echo e($message); ?>

                                </strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-lg-6">
                            <label class="my-1">NID Photo</label>
                            <input type="file" class="form-control" placeholder="Choose Photo" name="nid_photo">

                        </div>
                    </div>


                    <div class="row my-3">

                        <div class="col-lg-6">
                            <label class="my-1">Joining Date</label>
                            <input type="date" name="joining_date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>">
                            <?php $__errorArgs = ['joining_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger">
                                    <?php echo e($message); ?>

                                </strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-lg-6">
                            <label class="my-1">Photo</label>
                            <input type="file" class="form-control" placeholder="Choose Photo" name="photo">
                            <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger">
                                    <?php echo e($message); ?>

                                </strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>


                    <div class="col-auto mt-3">
                        <button type="submit" class="btn btn-primary mb-3">Save</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\erp-solution\resources\views/admin/employee/createEmployee.blade.php ENDPATH**/ ?>