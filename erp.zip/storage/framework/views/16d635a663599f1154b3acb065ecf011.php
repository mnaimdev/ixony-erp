<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">


        <div class="col-lg-12 m-auto col-sm-12 col-md-12">
            <a href="<?php echo e(route('product')); ?>" class="btn btn-primary my-3">List</a>

            <div class="card">
                <div class="card-header">
                    <h3 class="text-center">View Product</h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <ul class="list-group">
                                <li class="list-group-item"><b>Title: </b><?php echo e($product->title); ?></li>
                                <li class="list-group-item"><b>Series: </b><?php echo e($product->series); ?></li>
                                <li class="list-group-item"><b>Details: </b><?php echo e($product->details); ?></li>
                                <li class="list-group-item"><b>Model: </b><?php echo e($product->model); ?></li>
                                <li class="list-group-item"><b>Category: </b><?php echo e($product->category); ?></li>
                                <li class="list-group-item"><b>Brand: </b><?php echo e($product->brand); ?></li>

                            </ul>
                        </div>


                        <div class="col-lg-6">
                            <ul class="list-group">
                                <li class="list-group-item"><b>Origin: </b><?php echo e($product->origin); ?></li>
                                <li class="list-group-item"><b>Country of Manufacturing:
                                    </b><?php echo e($product->country_of_manufacturing); ?></li>
                                <li class="list-group-item"><b>Base Unit: </b><?php echo e($product->base_unit); ?></li>
                                <li class="list-group-item"><b>Current Price: </b><?php echo e($product->current_price); ?></li>
                                <li class="list-group-item"><b>Current Stock: </b><?php echo e($product->current_stock); ?></li>
                                <li class="list-group-item"><b>Stock Limit: </b><?php echo e($product->stock_limit); ?></li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\default-structure\resources\views/admin/product/view.blade.php ENDPATH**/ ?>