<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
        integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">

    <title>Download</title>
</head>

<body>
    <div class="container" style="margin-top: 100px;">



        <div class="row">

            <div class="col-lg-12 col-sm-12 col-md-12">
                <div class="card" id="card">

                    <div class="card-header p-3">
                        <h4 class="text-center" style="color: rgb(204, 25, 25)">IXONY ENGINEERING LIMITED</h4>
                    </div>

                    <div class="card-body">

                        <?php if(session('category_del')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('category_del')); ?>

                            </div>
                        <?php endif; ?>

                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Title</th>
                                    <th>Series</th>
                                    <th>Model</th>
                                    
                                    <th>Stock</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($sl + 1); ?></td>
                                        <td><?php echo e($product->title == '' ? 'NA' : $product->title); ?></td>
                                        <td><?php echo e($product->series == '' ? 'NA' : $product->series); ?></td>
                                        <td><?php echo e($product->model == '' ? 'NA' : $product->model); ?></td>
                                        
                                        <td><?php echo e($product->current_stock == '' ? 'NA' : $product->current_stock); ?></td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>




        </div>
    </div>





    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous">
    </script>

</body>

</html>
<?php /**PATH D:\Working Directory\Laravel\erp-solution\resources\views/admin/product/download.blade.php ENDPATH**/ ?>