<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">
        <a href="<?php echo e(route('Employee.Leave')); ?>" class="btn btn-primary my-2">Leave List</a>
        <div class="card">
            <div class="card-header">
                <h3 class="text-center">Employee Leave Request</h3>
            </div>

            <div class="card-body">
                <form class="col" method="POST" action="<?php echo e(route('Employee.Leave.Store')); ?>"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>



                    <div class="row">
                        <div class="col-lg-6">
                            <label class="my-1">Employee</label>
                            <select name="employee_id" class="form-control">
                                <option disabled selected>-- Select Employee --</option>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </select>
                            <?php $__errorArgs = ['employee_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger">
                                    <?php echo e($message); ?>

                                </strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                        </div>

                        <div class="col-lg-6">
                            <label class="my-1">Leave Date From</label>
                            <input type="date" class="form-control" name="date_from" value="<?php echo e(old('date_from')); ?>">
                            <?php $__errorArgs = ['date_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger">
                                    <?php echo e($message); ?>

                                </strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                    <div class="row my-3">
                        <div class="col-lg-6">
                            <label class="my-1">Leave Date To</label>
                            <input type="date" class="form-control" name="date_to" value="<?php echo e(old('date_to')); ?>">
                            <?php $__errorArgs = ['date_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger">
                                    <?php echo e($message); ?>

                                </strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-lg-6">
                            <label class="my-1">Details</label>
                            <textarea name="details" id="" cols="30" rows="4" class="form-control" placeholder="Details"><?php echo e(old('details')); ?></textarea>
                            <?php $__errorArgs = ['details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger">
                                    <?php echo e($message); ?>

                                </strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                    <div class="col-auto mt-3">
                        <button type="submit" class="btn btn-primary mb-3">Save</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\erp-solution\resources\views/admin/employee_leave/employeeLeave.blade.php ENDPATH**/ ?>