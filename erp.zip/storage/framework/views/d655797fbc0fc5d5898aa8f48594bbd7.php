<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">

        <div class="row">

            <div class="col-lg-12 col-sm-12 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="mt-2 text-center"><?php echo e($name); ?></h3>
                    </div>
                    <div class="card-body">

                        <table class="table table-striped">
                            <tr>
                                <th>SL</th>
                                <th>Title</th>
                                <th>Series</th>
                                <th>Model</th>
                                <th>Current Stock</th>
                            </tr>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($sl + 1); ?></td>
                                    <td><?php echo e($product->title == '' ? 'NA' : $product->title); ?></td>
                                    <td><?php echo e($product->series == '' ? 'NA' : $product->series); ?></td>
                                    <td><?php echo e($product->model == '' ? 'NA' : $product->model); ?></td>

                                    <td><?php echo e($product->current_stock == '' ? 'NA' : $product->current_stock); ?></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>

                    </div>
                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\erp-solution\resources\views/admin/category/categoryProduct.blade.php ENDPATH**/ ?>