<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TransactionBundleController extends Controller
{
    //
}
