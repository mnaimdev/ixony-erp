<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">

        <div class="row">

            <div class="col-lg-12 col-sm-12 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="mt-2">Searching Products</h3>
                    </div>
                    <div class="card-body">


                        <table class="table table-striped" id="table">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Title</th>
                                    <th>Series</th>
                                    <th>Model</th>
                                    <th>Stock</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($sl + 1); ?></td>
                                        <td><?php echo e($product->title == '' ? 'NA' : $product->title); ?></td>
                                        <td><?php echo e($product->series == '' ? 'NA' : $product->series); ?></td>
                                        <td><?php echo e($product->model == '' ? 'NA' : $product->model); ?></td>
                                        <td><?php echo e($product->current_stock == '' ? 'NA' : $product->current_stock); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('product.view', $product->id)); ?>"
                                                class="btn btn-info text-white">View</a>
                                            <a href="<?php echo e(route('product.edit', $product->id)); ?>"
                                                class="btn btn-primary">Edit</a>
                                            </button>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    No Product Match
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\erp-solution\resources\views/admin/product/searchProduct.blade.php ENDPATH**/ ?>