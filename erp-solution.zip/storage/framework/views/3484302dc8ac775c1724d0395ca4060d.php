<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row" style="margin-top: 100px;">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Employee Resigned List</h3>
                    </div>
                    <div class="card-body pt-0">
                        <table class="table table-striped">
                            <thead>
                                <th>SL</th>
                                <th>Name</th>
                                <th>Designation</th>
                                <th>Photo</th>
                                <th>Status</th>
                                <th>Duration</th>
                                <th>Action</th>
                            </thead>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tbody>

                                    <tr>
                                        <td>
                                            <?php echo e($sl + 1); ?>

                                        </td>
                                        <td>
                                            <h5 class="font-14 my-1 fw-normal"><?php echo e($employee->name); ?></h5>
                                        </td>

                                        <td>
                                            <h5 class="font-14 my-1 fw-normal"><?php echo e($employee->designation); ?></h5>
                                        </td>


                                        <td>
                                            <img width="50" height="50"
                                                src="<?php echo e(asset('/uploads/employee')); ?>/<?php echo e($employee->photo); ?>"
                                                alt="">
                                        </td>
                                        <td>
                                            <a class="btn btn-danger">Resigned</a>
                                        </td>

                                        <td>
                                            <?php
                                                $joiningDate = Carbon\Carbon::parse($employee->joining_date);
                                                $resignedDate = Carbon\Carbon::parse($employee->resigned_date);
                                                $duration = $resignedDate->diffInYears($joiningDate);
                                            ?>
                                            <span><?php echo e($duration); ?></span>
                                        </td>

                                        <td>
                                            <a href="<?php echo e(route('Employee.Resigned.View', $employee->id)); ?>"
                                                class="btn btn-primary">View</a>
                                        </td>
                                    </tr>

                                </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>

                    </div> <!-- end card-body-->
                </div> <!-- end card-->
            </div> <!-- end col-->

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\erp-solution\resources\views/admin/employee/resignedList.blade.php ENDPATH**/ ?>