<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">


        <div class="col-lg-12 m-auto col-sm-12 col-md-12">
            <a href="<?php echo e(route('Product.Challan.List')); ?>" class="btn btn-primary my-3">List</a>

            <div class="card">
                <div class="card-header">
                    <h3 class="text-center">View Challan</h3>
                </div>



                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <ul class="list-group">

                                <li class="list-group-item"><b>Date: </b><?php echo e($challan->date); ?></li>
                                <li class="list-group-item"><b>Challan No: </b><?php echo e($challan->challan_no); ?></li>
                                <li class="list-group-item"><b>Work Order No: </b><?php echo e($challan->work_order_no); ?></li>
                                <li class="list-group-item"><b>Status: </b><?php echo e($challan->status); ?></li>
                                <li class="list-group-item"><b>Created By: </b><?php echo e($challan->user->name); ?></li>


                            </ul>
                        </div>


                        <div class="col-lg-6">
                            <ul class="list-group">
                                <li class="list-group-item"><b>Customer Name: </b><?php echo e($challan->customer_name); ?></li>
                                <li class="list-group-item"><b>Contact Person: </b><?php echo e($challan->contact_person); ?></li>
                                <li class="list-group-item"><b>Contact Number: </b><?php echo e($challan->contact_number); ?></li>
                                <li class="list-group-item"><b>Delivery Location:
                                    </b><?php echo e($challan->delivery_location); ?></li>
                                <li class="list-group-item"><b>Returnable Type: </b><?php echo e($challan->returnable); ?></li>


                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\erp-solution\resources\views/admin/challan/viewChallan.blade.php ENDPATH**/ ?>