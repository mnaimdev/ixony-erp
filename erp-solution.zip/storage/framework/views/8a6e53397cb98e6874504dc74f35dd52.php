<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">
        <a href="<?php echo e(route('Product.Challan.List')); ?>" class="btn btn-primary my-3">Challan List</a>
        <div class="row">

            <div class="col-lg-8 col-sm-12 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="mt-2">Product List</h3>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <tr>
                                <th>SL</th>
                                <th>Product</th>
                                <th>Quantity</th>
                                <th>Challan No</th>
                                <th>Date</th>
                            </tr>
                            <?php $__currentLoopData = $challanProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($sl + 1); ?></td>
                                    <td><?php echo e($product->product->model); ?></td>
                                    <td><?php echo e($product->quantity); ?></td>
                                    <td>
                                        <?php
                                            $challanNo = App\Models\ChallanInfo::where('bundle_id', $bundleId)->first()->challan_no;
                                        ?>
                                        <?php echo e($challanNo); ?>

                                    </td>
                                    <td>
                                        <?php
                                            $date = App\Models\ChallanInfo::where('bundle_id', $bundleId)->first()->date;
                                        ?>
                                        <?php echo e($date); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>

                    </div>
                </div>
            </div>


            <div class="col-lg-4 col-sm-12 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3>Add Product</h3>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('Challan.Product.Store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>


                            <input type="hidden" name="bundle_id" value="<?php echo e($bundleId); ?>">

                            <div class="my-2">
                                <label>Product</label>
                                <select name="product_id" id="product_id" class="form-control select" style="width: 100%;">
                                    <option selected disabled>Select Product</option>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($product->id); ?>"><?php echo e($product->model); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-danger">
                                        <?php echo e($message); ?>

                                    </strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="my-2">
                                <label>Quantity</label>
                                <input type="number" id="quantity" name="quantity" placeholder="Quantity"
                                    class="form-control" value="<?php echo e(old('quantity')); ?>">
                                <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-danger">
                                        <?php echo e($message); ?>

                                    </strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <div class="my-2">
                                <button class="btn btn-primary">Add</button>
                            </div>


                        </form>
                    </div>
                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\erp-solution\resources\views/admin/challan/challanProduct.blade.php ENDPATH**/ ?>