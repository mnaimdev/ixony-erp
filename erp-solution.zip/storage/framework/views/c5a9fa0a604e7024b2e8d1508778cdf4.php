<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px">
        <a href="<?php echo e(route('Employee.Leave.Create')); ?>" class="btn btn-primary my-2">Add Leave Request</a>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Leave List</h3>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <th>SL</th>
                                <th>Employee</th>
                                <th>Date From</th>
                                <th>Date To</th>
                                <th>Total (Days)</th>
                                <th>Details</th>
                                <th>Action</th>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $employeeLeave; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl => $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($sl + 1); ?></td>
                                        <td><?php echo e($leave->employee->name); ?></td>
                                        <td><?php echo e($leave->date_from); ?></td>
                                        <td><?php echo e($leave->date_to); ?></td>
                                        <td>
                                            <?php
                                                $leaveFrom = Carbon\Carbon::parse($leave->date_from);
                                                $leaveTo = Carbon\Carbon::parse($leave->date_to);
                                                
                                            ?>
                                            <?php echo e($leaveTo->diffInDays($leaveFrom)); ?>

                                        </td>
                                        <td><?php echo e($leave->details); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('Employee.Leave.Edit', $leave->id)); ?>"
                                                class="btn btn-primary">Edit</a>

                                            <a data-delete="<?php echo e(route('Employee.Leave.Delete', $leave->id)); ?>"
                                                class="btn btn-danger delete">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script>
        const deleteBtn = document.querySelectorAll('.delete');
        deleteBtn.forEach((item) => {
            item.addEventListener('click', function() {
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        const link = this.getAttribute('data-delete');
                        location.href = link;
                    }
                })
            });
        });
    </script>


    <?php if(session('employee_leave_delete')): ?>
        <script>
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
            })

            Toast.fire({
                icon: 'success',
                title: '<?php echo e(session('employee_leave_delete')); ?>'
            })
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\erp-solution\resources\views/admin/employee_leave/employeeLeaveList.blade.php ENDPATH**/ ?>