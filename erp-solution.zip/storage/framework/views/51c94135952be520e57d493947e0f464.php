<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px">
        <a href="<?php echo e(route('Employee.Leave')); ?>" class="btn btn-primary my-2">Leave Request</a>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Manage Leave</h3>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <th>SL</th>
                                <th>Employee</th>
                                <th>Holiday</th>
                                <th>Taken</th>
                                <th>Available</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $employeeHoliday = App\Models\EmployeeHoliday::where('employee_id', $employee->id)->first();
                                        
                                        $holiday = $employeeHoliday == '' ? 0 : $employeeHoliday->holiday;
                                        
                                        $employeeHolidayTaken = App\Models\EmployeeLeave::where('employee_id', $employee->id)->sum('total');
                                        
                                        $availableHoliday = $holiday - $employeeHolidayTaken;
                                        
                                    ?>

                                    <tr>
                                        <td><?php echo e($sl + 1); ?></td>
                                        <td><?php echo e($employee->name); ?></td>
                                        <td>
                                            <?php echo e($holiday); ?>

                                        </td>
                                        <td>
                                            <?php echo e($employeeHolidayTaken); ?>

                                        </td>
                                        <td>
                                            <?php echo e($availableHoliday); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\erp-solution\resources\views/admin/employee_holiday/manageLeave.blade.php ENDPATH**/ ?>