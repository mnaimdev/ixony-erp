<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">


        <div class="col-lg-12 m-auto col-sm-12 col-md-12">
            <a href="<?php echo e(route('Employee')); ?>" class="btn btn-primary my-3">List</a>

            <div class="card">
                <div class="card-header">
                    <h3 class="text-center">View Employee</h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <ul class="list-group">
                                <li class="list-group-item"><b>Name: </b><?php echo e($employee->name); ?></li>
                                <li class="list-group-item"><b>Email: </b><?php echo e($employee->email); ?></li>
                                <li class="list-group-item"><b>Designation: </b><?php echo e($employee->designation); ?></li>
                                <li class="list-group-item"><b>Current Address: </b><?php echo e($employee->current_address); ?></li>
                                <li class="list-group-item"><b>Permanent Address: </b><?php echo e($employee->permanent_address); ?>

                                </li>

                                <li class="list-group-item"><b>Photo: </b>
                                    <Img width="100" height="100"
                                        src="<?php echo e(asset('/uploads/employee')); ?>/<?php echo e($employee->photo); ?>">
                                </li>


                            </ul>
                        </div>


                        <div class="col-lg-6">
                            <ul class="list-group">

                                <li class="list-group-item"><b>Personal Contact Number:
                                    </b><?php echo e($employee->personal_contact_number); ?>

                                </li>

                                <li class="list-group-item"><b>Office Contact Number:
                                    </b><?php echo e($employee->office_contract_number); ?>

                                </li>
                                <li class="list-group-item"><b>Whatsapp Number:
                                    </b><?php echo e($employee->whatsapp_number); ?>

                                </li>
                                <li class="list-group-item"><b>NID Number:
                                    </b><?php echo e($employee->nid_number); ?>

                                </li>

                                <?php
                                    $date = new DateTime($employee->joining_date);
                                ?>

                                <li class="list-group-item"><b>Joining Date:
                                    </b> <?php echo e($date->format('d-m-Y')); ?>

                                </li>

                                <li class="list-group-item"><b>NID Photo: </b>
                                    <Img width="100" height="100"
                                        src="<?php echo e(asset('/uploads/employee/nid')); ?>/<?php echo e($employee->nid_photo); ?>">
                                </li>


                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\erp-solution\resources\views/admin/employee/viewEmployee.blade.php ENDPATH**/ ?>