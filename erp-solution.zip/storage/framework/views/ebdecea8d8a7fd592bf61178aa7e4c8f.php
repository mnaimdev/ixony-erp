<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">
        <div class="row">

            <div class="col-lg-8 m-auto col-sm-12 col-md-12">
                <a href="<?php echo e(route('Product.Purchase.List')); ?>" class="btn btn-primary my-3">List</a>

                <div class="card">
                    <div class="card-header">
                        <h3 class="mt-2 text-center">Edit Purchase</h3>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('Product.Purchase.Update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <input type="hidden" name="id" value="<?php echo e($purchase->id); ?>">

                            <div class="my-2">
                                <label>Product</label>
                                <select name="product_id" id="product_id" class="form-control">
                                    <option selected disabled>Select Product</option>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($product->id); ?>"
                                            <?php echo e($product->id == $purchase->product_id ? 'selected' : ''); ?>>
                                            <?php echo e($product->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>


                            </div>

                            <div class="my-2">
                                <label>Quantity</label>
                                <input type="number" id="quantity" name="quantity" placeholder="Quantity"
                                    class="form-control" value="<?php echo e($purchase->quantity); ?>">

                            </div>

                            <div class="my-2">
                                <button type="submit" class="btn btn-primary">Update</button>

                            </div>

                    </div>

                    </form>
                </div>
            </div>
        </div>


    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\default-structure\resources\views/admin/purchase/editPurchase.blade.php ENDPATH**/ ?>