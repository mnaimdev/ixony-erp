<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">
        <button type="button" class="btn btn-primary my-3" data-toggle="modal" data-target="#exampleModal">
            Add New
        </button>
        <div class="row">

            <div class="col-lg-12 col-sm-12 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="mt-2">Challan List</h3>
                    </div>
                    <div class="card-body">

                        <table class="table table-striped">
                            <tr>
                                <th>SL</th>
                                <th>Date</th>
                                <th>Challan No</th>
                                <th>Work Order No</th>
                                <th>Return Type</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            <?php $__currentLoopData = $challans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl => $challan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($sl + 1); ?></td>
                                    <td><?php echo e($challan->date); ?></td>
                                    <td><?php echo e($challan->challan_no); ?></td>
                                    <td><?php echo e($challan->work_order_no); ?></td>
                                    <td><?php echo e($challan->returnable); ?></td>

                                    <td>
                                        <div class="custom-control custom-switch">
                                            <input data-id="<?php echo e($challan->id); ?>" class="toggle-class" type="checkbox"
                                                data-onstyle="success" data-offstyle="danger" data-toggle="toggle"
                                                data-on="Active" data-off="InActive"
                                                <?php echo e($challan->status == 'Pending' ? '' : 'checked'); ?>>

                                        </div>



                                    </td>

                                    <td>
                                        <a href="<?php echo e(route('Product.Challan.Edit', $challan->id)); ?>"
                                            class="btn btn-primary">Edit</a>

                                        <a href="<?php echo e(route('Product.Challan.View', $challan->id)); ?>"
                                            class="btn btn-primary">View</a>

                                        <a href="<?php echo e(route('Challan.Product.Add', $challan->bundle_id)); ?>"
                                            class="btn btn-info">Product</a>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>
                    </div>
                </div>
            </div>



            <!-- Modal -->
            
            <div class="modal fade" id="exampleModal" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title m-auto" id="exampleModalLabel">Create New Challan</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('Product.Challan.Store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>

                                


                                <div class="col-lg-12">
                                    <div class="my-2">
                                        <label>Date</label>
                                        <input type="date" id="date" name="date" placeholder="Date"
                                            class="form-control" value="<?php echo e(old('date')); ?>">
                                        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <strong class="text-danger">
                                                <?php echo e($message); ?>

                                            </strong>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>


                                <div class="col-lg-12">
                                    <div class="my-2">
                                        <label>Challan No</label>
                                        <input type="text" id="challan_no" name="challan_no" placeholder="Challan No"
                                            class="form-control" value="<?php echo e(old('challan_no')); ?>">

                                        <?php $__errorArgs = ['challan_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <strong class="text-danger">
                                                <?php echo e($message); ?>

                                            </strong>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>


                                <div class="col-lg-12">
                                    <div class="my-2">
                                        <label>Work Order No</label>
                                        <input type="text" id="work_order_no" name="work_order_no"
                                            placeholder="Work Order No" class="form-control"
                                            value="<?php echo e(old('work_order_no')); ?>">

                                        <?php $__errorArgs = ['work_order_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <strong class="text-danger">
                                                <?php echo e($message); ?>

                                            </strong>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>


                                <div class="col-lg-12">
                                    <div class="my-2">
                                        <label>Customer Name</label>
                                        <input type="text" id="customer_name" name="customer_name"
                                            placeholder="Customer Name" class="form-control"
                                            value="<?php echo e(old('customer_name')); ?>">
                                        <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <strong class="text-danger">
                                                <?php echo e($message); ?>

                                            </strong>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>



                                <div class="col-lg-12">
                                    <div class="my-2">
                                        <label>Delivery Location</label>
                                        <input type="text" id="delivery_location" name="delivery_location"
                                            placeholder="Delivery Location" class="form-control"
                                            value="<?php echo e(old('delivery_location')); ?>">

                                    </div>
                                </div>


                                <div class="col-lg-12">
                                    <div class="my-2">
                                        <label>Contact Person</label>
                                        <input type="text" id="contact_person" name="contact_person"
                                            placeholder="Contact Person" class="form-control"
                                            value="<?php echo e(old('contact_person')); ?>">

                                    </div>
                                </div>


                                <div class="col-lg-12">
                                    <div class="my-2">
                                        <label>Contact Number</label>
                                        <input type="number" id="contact_number" name="contact_number"
                                            placeholder="Contact Number" class="form-control"
                                            value="<?php echo e(old('contact_number')); ?>">


                                    </div>
                                </div>



                                <div class="col-lg-12">
                                    <div class="my-2">
                                        <label>Returnable</label>
                                        <select name="returnable" class="form-control">
                                            <option selected disabled>Is Returnable</option>
                                            <option value="Yes" <?php echo e(old('returnable') == 'Yes' ? 'selected' : ''); ?>>Yes
                                            </option>
                                            <option value="No" <?php echo e(old('returnable') == 'No' ? 'selected' : ''); ?>>No
                                            </option>
                                        </select>


                                    </div>
                                </div>


                        </div>


                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    



    <script>
        $('.toggle-class').change(function() {
            var status = $(this).prop('checked') == true ? 'Complete' : 'Pending';
            var id = $(this).data('id');


            $.ajax({
                type: "GET",
                dataType: "json",
                url: '/challanStatus',
                data: {
                    'status': status,
                    'id': id
                },
                success: function(data) {
                    alert(data.success);
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\erp-solution\resources\views/admin/challan/challan.blade.php ENDPATH**/ ?>