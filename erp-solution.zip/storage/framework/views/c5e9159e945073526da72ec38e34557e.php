<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">

        <div class="row">

            <div class="col-lg-8 col-sm-12 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="mt-2">Show Category</h3>
                    </div>
                    <div class="card-body">

                        <?php if(session('category_del')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('category_del')); ?>

                            </div>
                        <?php endif; ?>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Category Name</th>
                                    
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($sl + 1); ?></td>
                                        <td><?php echo e($category->name); ?></td>
                                        

                                        <td>
                                            <a href="<?php echo e(route('category.edit', $category->id)); ?>"
                                                class="btn btn-primary">Edit</a>

                                            <a href="<?php echo e(route('category.product', $category->name)); ?>"
                                                class="btn btn-info">Product</a>

                                            <a data-delete="<?php echo e(route('category.delete', $category->id)); ?>"
                                                class="btn btn-danger delete">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>



            <div class="col-lg-4 col-sm-12 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="mt-2">Add Category</h3>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('category.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <?php if(session('category')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('category')); ?>

                                </div>
                            <?php endif; ?>

                            <div class="form-group">
                                <label>Category Name</label>
                                <input type="text" class="form-control" name="name">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            


                            <div class="form-group">
                                <img width="200" id="blah" alt="">
                            </div>

                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">Add</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\erp-solution\resources\views/admin/category/category.blade.php ENDPATH**/ ?>