<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">
        <div class="row">
            <div class="col-lg-12 col-sm-12 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="mt-2 text-center"><?php echo e($type); ?> Report</h3>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">

                            <tr>
                                <th>SL</th>
                                <th>Product</th>
                                <th>Quantity</th>
                                <th>Date</th>
                            </tr>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <td><?php echo e($sl + 1); ?></td>
                                    <td><?php echo e($product->product->model); ?></td>
                                    <td><?php echo e($product->quantity); ?></td>
                                    <td><?php echo e($date->format('d-m-Y')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>

                    </div>
                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\erp-solution\resources\views/admin/challan/reportProduct.blade.php ENDPATH**/ ?>