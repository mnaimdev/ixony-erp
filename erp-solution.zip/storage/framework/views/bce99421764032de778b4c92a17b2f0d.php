<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">
        <a href="<?php echo e(route('Employee.Holiday')); ?>" class="btn btn-primary my-2">Holiday List</a>
        <div class="card">
            <div class="card-header">
                <h3 class="text-center">Employee Holiday Edit</h3>
            </div>

            <div class="card-body">
                <form class="col" method="POST" action="<?php echo e(route('Employee.Holiday.Update')); ?>"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>


                    <input type="hidden" name="id" value="<?php echo e($holiday->id); ?>">



                    <div class="row">
                        <div class="col-lg-6">
                            <label class="my-1">Employee</label>
                            <select name="employee_id" class="form-control">
                                <option disabled selected>-- Select Employee --</option>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($employee->id); ?>"
                                        <?php echo e($holiday->employee_id == $employee->id ? 'selected' : ''); ?>>
                                        <?php echo e($employee->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                            <?php $__errorArgs = ['employee_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger">
                                    <?php echo e($message); ?>

                                </strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                        </div>

                        <div class="col-lg-6">
                            <label class="my-1">Total Holiday</label>
                            <input type="number" class="form-control" name="holiday" value="<?php echo e($holiday->holiday); ?>">
                            <?php $__errorArgs = ['holiday'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger">
                                    <?php echo e($message); ?>

                                </strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>



                    <div class="col-auto mt-3">
                        <button type="submit" class="btn btn-primary mb-3">Update</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\erp-solution\resources\views/admin/employee_holiday/editHoliday.blade.php ENDPATH**/ ?>